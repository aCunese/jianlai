document.addEventListener('DOMContentLoaded', () => {
    const copyButtons = document.querySelectorAll('.copy-btn');

    copyButtons.forEach(button => {
        button.addEventListener('click', () => {
            const quoteCard = button.closest('.quote-card');
            const quoteTextElement = quoteCard.querySelector('.quote-text');
            const authorElement = quoteCard.querySelector('.author');

            if (quoteTextElement && authorElement) {
                // 构建要复制的文本，包含引号和作者
                const textToCopy = `${quoteTextElement.innerText}\n${authorElement.innerText}`;

                // 使用 Clipboard API 尝试复制
                navigator.clipboard.writeText(textToCopy).then(() => {
                    // 复制成功提示
                    const originalText = button.textContent;
                    button.textContent = '已复制!';
                    button.style.backgroundColor = '#28a745'; // 绿色背景表示成功
                    button.style.color = '#ffffff'; // 白色文字

                    // 短暂延迟后恢复按钮文字和样式
                    setTimeout(() => {
                        button.textContent = originalText;
                        button.style.backgroundColor = ''; // 恢复默认背景
                        button.style.color = ''; // 恢复默认文字颜色
                    }, 1500); // 1.5秒后恢复

                }).catch(err => {
                    console.error('复制失败: ', err);
                    // 可以选择给用户一个失败提示
                    alert('复制失败，请手动复制。');
                });
            } else {
                console.error('无法找到语录或作者元素');
            }
        });
    });
});
