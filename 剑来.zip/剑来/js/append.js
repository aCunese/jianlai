// 这是 js/append.js 文件的内容
$(document).ready(function() {
    // 加载 header.html 到 class="nav" 的 div 中
    $(".nav").load("header.html", function(response, status, xhr) {
        if (status == "error") {
            console.error("加载 header.html 失败: " + xhr.status + " " + xhr.statusText);
            $(".nav").html("<p style='color:red;'>导航加载失败</p>");
        }
    });

    // 加载 footer.html 到 class="footer" 的 div 中
    $(".footer").load("footer.html", function(response, status, xhr) {
        if (status == "error") {
            console.error("加载 footer.html 失败: " + xhr.status + " " + xhr.statusText);
            $(".footer").html("<p style='color:red;'>页脚加载失败</p>");
        }
    });
});
