document.addEventListener('DOMContentLoaded', () => {

    // --- Hero Section Load Animation ---
    const heroSection = document.querySelector('.hero');
    if (heroSection) {
        // Add 'loaded' class after a short delay to trigger CSS transitions
        setTimeout(() => {
            heroSection.classList.add('loaded');
        }, 100); // Small delay to ensure transition works
    }

    // --- Scroll Animation Trigger ---
    const animatedElements = document.querySelectorAll('.animate-on-scroll');

    if ('IntersectionObserver' in window) {
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('is-visible');
                    // Optional: Unobserve after animation to improve performance
                    // observer.unobserve(entry.target);
                }
                // Optional: Reset animation when scrolling back up
                // else {
                //     entry.target.classList.remove('is-visible');
                // }
            });
        }, {
            threshold: 0.1 // Trigger when 10% of the element is visible
        });

        animatedElements.forEach(el => {
            observer.observe(el);
        });

    } else {
        // Fallback for older browsers (simply show elements)
        animatedElements.forEach(el => {
            el.style.opacity = 1;
        });
        console.warn("Intersection Observer not supported, scroll animations disabled.");
    }

    // --- Smooth scroll for internal links (if you add them later) ---
    // Example: <a href="#synopsis">...</a>
    const internalLinks = document.querySelectorAll('a[href^="#"]');
    internalLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetId = this.getAttribute('href');
            // Ensure it's a valid ID selector and not just "#"
            if (targetId.length > 1 && document.querySelector(targetId)) {
                e.preventDefault(); // Prevent default jump
                document.querySelector(targetId).scrollIntoView({
                    behavior: 'smooth',
                    block: 'start' // Align top of the target element to the top of the viewport
                });
            }
        });
    });

});
